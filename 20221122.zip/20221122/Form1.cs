﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _20221122
{
    public partial class Form1 : Form
    {
        database dbase = new database();
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            Gyumolcsokbetoltese();
        }

        private void Gyumolcsokbetoltese()
        {
            listBox_Gyumolcsok.Items.Clear();
            foreach (gyumolcs item in dbase.getAllgyumolcs())
            {
                listBox_Gyumolcsok.Items.Add(item);
            }
        }
        private void button_add_Click(object sender, EventArgs e)
        {
            if(HianyzoAdat())
            {
                return;
            }
            gyumolcs ujGyumolcs = new gyumolcs(1,textBox_name.Text, (double)numericUpDown_db.Value, (double)numericUpDown_price.Value);
            if(dbase.addgyumolcs(ujGyumolcs))
            {
                MessageBox.Show("Sikeres rögzítés");
                textBox_id.Text = "";
                textBox_name.Text = "";
                numericUpDown_db.Value = 0;
                numericUpDown_price.Value = 0;
            }
            else
            {
                MessageBox.Show("Rögzítés sikertelen!");
            }
            Gyumolcsokbetoltese();
        }

        private bool HianyzoAdat()
        {
            if(string.IsNullOrEmpty(textBox_name.Text))
            {
                MessageBox.Show("Érvénytelen gyümölcsnév");
                textBox_name.Focus();
                return true;
            }
            return false;
        }

        private void button_edit_Click(object sender, EventArgs e)
        {

        }


        private void button_delete_Click(object sender, EventArgs e)
        {

        }
    }
}
